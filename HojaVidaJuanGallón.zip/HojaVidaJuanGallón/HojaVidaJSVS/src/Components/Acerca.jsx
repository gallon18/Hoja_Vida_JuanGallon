const About = () => {
    return (
      <section className="section">
        <h2>QUIÉN SOY YO</h2>
        <p>
         Soy alguien responsable, con deseos de superación y mis metas están basadas 
         en el logro de objetivos claros; Aprendo rápido y cumplo de manera adecuada con puntualidad,
          honestidad y responsabilidad en las distintas actividades que realizo.
        </p>
        <p>
          Soy alguin a quien le gusta aprendes habilidades nuevas, conocer nuevos entornos de trbaajo,
          a quien le gustan los desafíos, si no soy apto para algo, me adapto a ello.
           Tengo habilidades para el manejo de 
          bases de datos, desarrollo de software y gestión de proyectos informáticos.
        </p>
      </section>
    );
  };
  
  export default About;