const Encabezado = () => {
    <header className="header">
     <h1>Juan de Dios Gallón Lozada</h1>
      <h2>Aprendiz Sena</h2>
      <div className="contact-info">
        <p>Ibagué, Colombia</p>
        <p>Teléfono: 3122068062</p>
        <p>Email: juangallonlozada507@gmail.com</p>
      </div>
    </header>
};

export default Encabezado;
